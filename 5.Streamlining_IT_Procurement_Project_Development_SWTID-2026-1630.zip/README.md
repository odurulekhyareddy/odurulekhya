# Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer

## Project Development Phase
These files are customized for the ServiceNow Flow Designer laptop procurement automation project.

### Included
- Functional & Performance Testing.docx
- Automation Performance Test.docx
- Reporting Performance Test.docx
- ServiceNow Platform Performance Test.docx
- Workflow Metrics Test.docx
- Procurement Dashboard Test.docx
- User Acceptance Testing FSD.docx
- UAT Report Template.pdf

The reference phase structure was used as a template; the project content is specific to this project.
