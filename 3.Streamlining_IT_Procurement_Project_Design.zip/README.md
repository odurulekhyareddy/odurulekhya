# Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer — Project Design Phase

These deliverables are customized from the supplied Project Design Phase reference templates.

## Documents
- Problem - Solution Fit Template
- Proposed Solution Template
- Solution Architecture

## Core solution
ServiceNow Service Catalog + Flow Designer automates standard laptop requests from submission through validation, approval, procurement task creation, notifications, fulfillment and closure.
