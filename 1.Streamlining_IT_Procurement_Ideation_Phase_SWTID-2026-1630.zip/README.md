# Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer

## Naan Mudhalvan Project — Ideation Phase

This repository contains the Ideation Phase deliverables for the project **Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer**.

### Objective
Streamline standard laptop procurement by using **ServiceNow Flow Designer** to reduce repetitive manual work, automate routing and notifications, validate request information, and create procurement tasks after the required approval.

### Included files
- `Empathy Map Canvas.docx` and `.pdf` — user needs, behaviours, pains and gains.
- `Brainstorming - Idea Generation - Prioritization Template.docx` and `.pdf` — solution ideas and prioritization.
- `Define Problem Statements Template.docx` and `.pdf` — customer-focused problem statements.

### Suggested solution flow
1. Employee submits a standard laptop request.
2. Flow Designer validates required request information.
3. Request is routed to the appropriate approver.
4. Approval notification is sent and escalation can be triggered when required.
5. After approval, a procurement task is created automatically.
6. IT/procurement teams process the order.
7. Requester receives status notifications until completion.

### Project topic
**Streamlining IT Procurement: Automating Standard Laptop Orders with Flow Designer**
